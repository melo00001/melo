-- report that shows the CategoryName and Description from the categories table sorted by CategoryName.

SELECT categoryname, description
FROM categories
ORDER BY CategoryName;

-- report that shows the ContactName, CompanyName, ContactTitle and Phone number from the customers table sorted by Phone.

SELECT contactname, companyname, contactTitle, Phone as phone_number
FROM customers
ORDER BY Phone;

-- report that shows the capitalized FirstName and capitalized LastName renamed as FirstName and Lastname respectively and HireDate from 
-- the employees table sorted from the newest to the oldest employee.

SELECT UPPER(FirstName) as first_name, UPPER(LastName) as last_name, HireDate
FROM employees
ORDER BY HireDate DESC;

-- report that shows the top 10 OrderID, OrderDate, ShippedDate, CustomerID, Freight from the orders table sorted by Freight in descending order.

SELECT orderid, orderdate, shippedDate, customerID, freight
FROM orders
ORDER BY Freight DESC
LIMIT 10;

-- report that shows all the CustomerID in lowercase letter and renamed as ID from the customers table.

SELECT LOWER(CustomerID) as ID
FROM customers;

-- report that shows the CompanyName, Fax, Phone, Country, HomePage from the suppliers table 
-- sorted by the Country in descending order then by CompanyName in ascending order.

SELECT companyname, fax, phone, country, homepage
FROM suppliers
ORDER BY country DESC, companyname ASC;

-- report that shows CompanyName, ContactName of all customers from ‘Buenos Aires' only.

SELECT companyname, contactname, city
FROM customers
WHERE city = 'Buenos Aires';

-- report showing ProductName, UnitPrice, QuantityPerUnit of products that are out of stock.

SELECT productname, unitprice, quantityperunit
FROM products
WHERE UnitsInStock = 0;

-- report showing all the ContactName, Address, City of all customers not from Germany, Mexico, Spain.

SELECT contactname, address, city
FROM customers
WHERE country NOT IN ('Germany', 'Mexico', 'Spain');

-- report showing OrderDate, ShippedDate, CustomerID, Freight of all orders placed on 21 May 1996.

SELECT orderdate, shippedDate, customerid, freight
FROM orders
WHERE OrderDate = '1996-5-21';

-- report showing FirstName, LastName, Country from the employees not from United States.

SELECT firstname, lastname, country
FROM employees
WHERE country != 'USA';

-- report that shows the EmployeeID, OrderID, CustomerID, RequiredDate, ShippedDate from all orders shipped later than the required date.

SELECT employeeid, orderid, customerid, requiredDate, shippedDate
FROM orders
WHERE shippedDate > requiredDate;

-- report that shows the City, CompanyName, ContactName of customers from cities starting with A or B.

SELECT contactname, city, companyname
FROM customers
WHERE city LIKE 'A%' OR city LIKE 'B%';

-- report showing all the even numbers of OrderID from the orders table.
SELECT orderid
FROM orders
WHERE OrderID % 2 = 0;

-- report that shows all the orders where the freight cost more than $500.

SELECT *
FROM orders 
WHERE freight > '500';

-- Create a report that shows the ProductName, UnitsInStock, UnitsOnOrder, ReorderLevel of all products that are up for reorder.

SELECT productname, unitsinstock, unitsonorder, reorderlevel
FROM products
WHERE reorderlevel > 0;

-- report that shows the CompanyName, ContactName number of all customer that have no fax number.

SELECT companyname, contactname, phone
FROM customers
WHERE fax is null;

-- report that shows the FirstName, LastName of all employees that do not report to anybody.

SELECT firstname, lastname
FROM employees
WHERE reportsto IS NULL;

-- report showing all the odd numbers of OrderID from the orders table.
 
 SELECT orderid
 FROM orders
 WHERE orderid % 2 != 0;
 
 -- report that shows the CompanyName, ContactName, Fax of all customers that do not have Fax number and sorted by ContactName.
 
 SELECT companyname, contactname, fax
 FROM customers
 WHERE fax is null
 ORDER BY contactname;
 
 -- report that shows the City, CompanyName, ContactName of customers from cities that has letter L in the name sorted by ContactName.
 
 SELECT city, companyname, contactname
 FROM customers
 WHERE city LIKE '%L%'
 ORDER BY contactname;
 
 -- report that shows the FirstName, LastName, BirthDate of employees born in the 1950s
 
 SELECT firstname, lastname, birthdate
 FROM employees
 WHERE YEAR(BirthDate) BETWEEN 1950 AND 1959;
 
 -- report that shows the FirstName, LastName, the year of Birthdate as birth year from the employees table.
 
 SELECT firstname, lastname, YEAR(birthdate) as birth_year
 FROM employees;
 
 -- report showing OrderID, total number of Order ID as NumberofOrders from the orderdetails table
 -- grouped by OrderID and sorted by NumberofOrders in descending order.
 
 SELECT orderid, count(orderid) as no_of_orders
 FROM `order details`
 GROUP BY orderid
 ORDER BY no_of_orders DESC;
 
 -- report that shows the SupplierID, ProductName, CompanyName from all product
 -- Supplied by Exotic Liquids, Specialty Biscuits, Ltd., Escargots Nouveaux sorted by the supplier ID
 
 SELECT suppliers.SupplierID, products.productname, suppliers.companyname
 FROM products
 JOIN suppliers on products.SupplierID = suppliers.SupplierID
 WHERE suppliers.companyname in ('Exotic Liquids', 'Specialty Biscuits Ltd', 'Escargots Nouveaux')
 ORDER BY suppliers.CompanyName;

-- report that shows the ShipPostalCode, OrderID, OrderDate, RequiredDate, ShippedDate, ShipAddress of all orders with ShipPostalCode beginning with "98124".

SELECT shipPostalcode, orderid, orderdate, requiredDate, shippedDate, shipaddress
FROM orders
WHERE shipPostalcode LIKE '98124%';

-- report that shows the ContactName, ContactTitle, CompanyName of customers that the has no "Sales" in their ContactTitle.

SELECT contactname, contactTitle, companyname
FROM customers
WHERE contactTitle NOT LIKE '%Sales%';

-- report that shows the LastName, FirstName, City of employees in cities other "Seattle"

 SELECT lastname, firstname, city
 FROM employees
 WHERE city != 'Seattle';
 
 -- report that shows the CompanyName, ContactTitle, City, Country of all customers in any city in Mexico or other cities in Spain other than Madrid
 
 SELECT companyname, contactTitle, city, country
 FROM customers
 WHERE country = 'Mexico' or (country = 'Spain' and city <> 'Madrid');
 
SELECT concat(firstname, ' ', lastname, ' ', 'can be reached at', ' ', 'x', extension)
as ContactInfo
FROM employees;

-- report that shows the ContactName of all customers that do not have letter A as the second alphabet in their Contactname.

SELECT contactname
FROM customers
WHERE substring(contactname, 2, 1) != 'A';

-- report that shows the average UnitPrice rounded to the next whole number, total price of UnitsInStock and maximum number of orders from the products table.
-- All saved as AveragePrice, TotalStock and MaxOrder respectively

SELECT round(avg(unitprice)) as AveragePrice, sum(unitsinstock) as TotalStock, max(unitsonorder) as MaxOrder
FROM products;

-- report that shows the SupplierID, CompanyName, CategoryName, ProductName and UnitPrice from the products, suppliers and categories table

SELECT p.supplierid, s.companyname, c.categoryname, p.productname, p.unitprice
FROM products as p 
JOIN suppliers as s on p.supplierid = s.supplierid
JOIN categories as c on p.categoryid = c.categoryid;

-- report that shows the CustomerID, sum of Freight, from the orders table with sum of freight greater $200, grouped by CustomerID

SELECT customerid, sum(freight) as sum_of_freight
FROM orders
GROUP BY customerid
HAVING sum(freight) > 200;

-- report that shows the OrderID ContactName, UnitPrice, Quantity, Discount from the order details,
-- orders and customers table with discount given on every purchase
 
SELECT od.orderid, c.contactname, od.unitprice, od.quantity, od.discount
FROM `order details` as od
JOIN orders as o on od.orderid = o.orderid
JOIN customers as c on o.customerid = c.customerid;

-- report that shows the EmployeeID, the LastName and FirstName as employee, and
-- the LastName and FirstName of who they report to as manager from the employees table sorted by Employee

SELECT e.employeeid, e.lastname as employee_lastname, e.firstname as employee_firstname, m.lastname as manager_lastname, m.firstname as manager_firstname
FROM employees as e
LEFT JOIN employees as m on e.reportsto = m.employeeid
ORDER BY e.employeeid;

-- report that shows the average, minimum and maximum UnitPrice of all products as AveragePrice, MinimumPrice and MaximumPrice respectively

SELECT avg(unitprice) as average_price, min(unitprice) as minimum_price, max(unitprice) as maximum_price
FROM products;

-- Creating a view named CustomerInfo that shows the CustomerID, CompanyName, ContactName, ContactTitle, Address,
-- City, Country, Phone, OrderDate, RequiredDate, ShippedDate from the customers and orders table

CREATE VIEW CustomerInfo as 
SELECT c.customerid, c.companyname, c.contactname, c.contactTitle,
	c.address, c.city, c.country, c.phone, o.orderdate,
    o.requiredDate, o.shippedDate
FROM customers as c
JOIN orders as o on c.customerid = o.customerid;

-- Creating a view named Customerdetails and selecting all values from customerinfo as values for Customerdetails
CREATE VIEW CustomerDetails as
SELECT * FROM customerinfo;

-- Creating a view named ProductDetails that shows the ProductID, CompanyName, ProductName, CategoryName, Description, QuantityPerUnit,
-- UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued from the supplier, products and categories tables

CREATE VIEW ProductDetails as
SELECT p.productid, s.companyname, p.productname, c.categoryname, c.description, p.quantityperunit, p.unitprice,
       p.unitsinstock, p.unitsonorder, p.reorderlevel, p.discontinued
FROM products as p
JOIN suppliers as s on p.supplierid = s.supplierid
JOIN categories as c on p.categoryid = c.categoryid;

-- Dropping the customerdetails view
DROP VIEW IF EXISTS customerdetails;

-- report that fetch the first 5 character of categoryName from the category tables and renamed as ShortInfo

SELECT LEFT(categoryname, 5) as ShortInfo 
FROM categories;

-- copy of the shipper table as shippers_duplicate. 

CREATE TABLE shippers_duplicate LIKE shippers;

INSERT INTO shippers_duplicate
SELECT * FROM shippers;

-- Adding a new column 'Email' to the shippers_duplicate table.
ALTER TABLE shippers_duplicate
ADD COLUMN Email VARCHAR(50);

-- Updating the 'Email' column with values for specific rows using WHERE clause
UPDATE shippers_duplicate
SET Email = 'speedyexpresss@gmail.com'
WHERE shipperid = 1;

UPDATE shippers_duplicate
SET Email = 'unitedpackage@gmail.com'
WHERE shipperid = 2;

UPDATE shippers_duplicate
SET Email = 'federalshipping@gmail.com'
WHERE shipperid = 3;

-- Displaying all values from the shippers_duplicate table
SELECT * FROM shippers_duplicate;

-- report that shows the CompanyName and ProductName from all product in the Seafood category.

SELECT suppliers.companyname, products.productname
FROM products
JOIN suppliers on products.supplierid = suppliers.supplierid
WHERE products.categoryid = (SELECT categoryid FROM categories WHERE categoryname = 'Seafood');

-- report that shows the CategoryID, CompanyName and ProductName from all product in the categoryID 5.

SELECT p.categoryid, s.companyname, p.productname
FROM products as p
JOIN suppliers as s on p.supplierid = s.supplierid
JOIN categories as c on p.categoryid = c.categoryid
WHERE p.categoryid =5;

-- Deleting the shippers_duplicate table.

DROP TABLE shippers_duplicate;

SELECT Lastname, Firstname, Title, concat(TIMESTAMPDIFF(YEAR, birthdate, CURDATE()), ' ','Years') as Age
FROM employees;

-- report that the CompanyName and total number of orders by customer renamed as number of orders since Decemeber 31, 1994

SELECT companyname, count(orderid) as no_of_orders
FROM customers
JOIN orders on customers.customerid = orders.customerid
WHERE orderdate >= '1994-12-31'
GROUP BY companyname
HAVING COUNT(orderid) > 10;

SELECT concat(productname, ' ','weigh/is', ' ', quantityperunit, ' ', 'and costs', ' ', '$',round(unitprice))
as ProductInfo
FROM products;